using UnityEngine;

public class OpenWebsite : MonoBehaviour
{
    // URL to open
    public string websiteURL = "https://www.example.com";

    // Method to open the website
    public void OpenWebsiteLink()
    {
        Application.OpenURL(websiteURL);
    }
}