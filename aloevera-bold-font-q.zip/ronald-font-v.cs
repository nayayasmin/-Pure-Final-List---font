using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;

public class VideoControl : MonoBehaviour
{
    public VideoPlayer videoPlayer;  // Reference to the VideoPlayer component
    public Button playButton;  // Reference to the Play button
    public Button stopButton;  // Reference to the Stop button

    void Start()
    {
        // Attach the Play and Stop methods to their respective button click events
        playButton.onClick.AddListener(PlayVideo);
        stopButton.onClick.AddListener(StopVideo);

        // Subscribe to the video player's loopPointReached event to detect when the video ends
        videoPlayer.loopPointReached += EndReached;
    }

    // Play the video
    void PlayVideo()
    {
        if (videoPlayer != null)
        {
            videoPlayer.Play();
            Debug.Log("Video is now playing.");
        }
        else
        {
            Debug.LogError("VideoPlayer reference is missing!");
        }
    }

    // Stop the video
    void StopVideo()
    {
        if (videoPlayer != null)
        {
            videoPlayer.Stop();
            Debug.Log("Video has stopped.");
        }
        else
        {
            Debug.LogError("VideoPlayer reference is missing!");
        }
    }

    // This method is called when the video finishes
    void EndReached(VideoPlayer vp)
    {
        Debug.Log("Video playback finished.");
    }
}
