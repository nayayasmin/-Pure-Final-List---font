using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class ButtonSoundPlayer : MonoBehaviour
{
    public AudioClip soundClip;  // Drag your audio clip here in the Inspector
    public float delayBeforeSceneChange = 0.5f;  // Adjust delay to fit the sound length
    public string sceneNameToLoad;  // Set the scene name you want to load
    private AudioSource audioSource;

    void Start()
    {
        // Ensure there's an AudioSource component attached to the object
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.clip = soundClip;  // Assign the clip to the audio source
    }

    // Method to play the sound and then change the scene
    public void PlaySoundAndChangeScene()
    {
        if (soundClip != null)
        {
            audioSource.PlayOneShot(soundClip);  // Play the sound
            StartCoroutine(WaitAndChangeScene());  // Wait for sound before scene change
        }
    }

    // Coroutine to delay the scene change
    IEnumerator WaitAndChangeScene()
    {
        yield return new WaitForSeconds(delayBeforeSceneChange);  // Wait for the sound
        SceneManager.LoadScene(sceneNameToLoad);  // Change the scene
    }
}